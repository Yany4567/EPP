//
//  RequestWithGET.m
//  HiWeedend
//
//  Created by lanou3g on 16/4/20.
//  Copyright © 2016年 高艳闯. All rights reserved.
//

#import "RequestWithGET.h"

@implementation RequestWithGET

@end
