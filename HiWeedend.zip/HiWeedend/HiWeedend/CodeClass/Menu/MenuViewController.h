//
//  MenuViewController.h
//  Leisure
//
//  Created by wenze on 16/3/28.
//  Copyright © 2016年 wenze. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuViewController : UIViewController

@end
