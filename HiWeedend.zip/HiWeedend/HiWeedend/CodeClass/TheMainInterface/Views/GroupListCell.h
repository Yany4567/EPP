//
//  GroupListCell.h
//  HiWeedend
//
//  Created by lanou3g on 16/4/17.
//  Copyright © 2016年 高艳闯. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GroupListCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *civerImage;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *TitleLabel;

@end
